﻿public enum EnumJudge
{
    NOTYET,
    COOL,
    PERFECT,
    GREAT,
    GOOD,
    BAD
        
}

