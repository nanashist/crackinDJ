﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NAudio;
using NAudio.Wave;

/// <summary>
/// ステレオ音声ストリーミングバッファー(16bitPCM)
/// </summary>
public class StreamingBuffer
{
    private double _streambuffermsec;
    private int _SamplingRate;
    private int _Channels;
    /// <summary>
    /// AddSampleがバイト配列しか受け付けないのでIEEEではなくPCMで無いと扱えない
    /// </summary>
    private BufferedWaveProvider bufwaveprovider16;
    private VolumeWaveProvider16 volume;
    private Int16Buffer[] ChannelBuffers;

    #region"プロパティ

    /// <summary>
    /// ストリーミングバッファの音量(R/W)
    /// </summary>
    public float Volume { get { return volume.Volume; } set { volume.Volume = value; } }
    /// <summary>
    /// サンプリングレート
    /// </summary>
    public int SampleRate { get { return volume.WaveFormat.SampleRate; } }
    /// <summary>
    /// チャンネル数
    /// </summary>
    public int Channels { get { return volume.WaveFormat.Channels; } }
    /// <summary>
    /// ミキサーに渡す(R)
    /// </summary>
    public IWaveProvider OutputWaveProvider { get { return new Wave16ToFloatProvider(volume); } }

    public TimeSpan BufferedDuration { get { return bufwaveprovider16.BufferedDuration; } }
    #endregion

    public StreamingBuffer(WaveFormat waveformat)
    {
        _SamplingRate = waveformat.SampleRate;
        _Channels = waveformat.Channels;
        bufwaveprovider16 = new BufferedWaveProvider(new WaveFormat(_SamplingRate, 16, _Channels));

        volume = new VolumeWaveProvider16(bufwaveprovider16);
        //volume.Volume = 0.1F;
        ChannelBuffers = new Int16Buffer[2];
        ChannelBuffers[0] = new Int16Buffer();
        ChannelBuffers[1] = new Int16Buffer();
        _streambuffermsec = 500;//小さいほど良いが正常動作する限界値をセットしたい。この値を下回るタイミングでbufwaveproviderにバッファを追加していく
    }

    /// <summary>
    /// ストリーミングバッファにデータを追加
    /// </summary>
    /// <param name="lbuf"></param>
    /// <param name="rbuf"></param>
    /// <param name="mergesize"></param>
    public void AddFloatBuffer(List<float> lbuf, List<float> rbuf, int mergesize)
    {
        AddInt16Buffer(floatList2int16List(lbuf), floatList2int16List(rbuf), mergesize);
    }

    /// <summary>
    /// ストリーミングバッファにデータを追加
    /// </summary>
    /// <param name="lbuf"></param>
    /// <param name="rbuf"></param>
    /// <param name="mergesize"></param>
    public void AddInt16Buffer(List<Int16> lbuf, List<Int16> rbuf, int mergesize)
    {
        ChannelBuffers[0].AddBuffer(lbuf, mergesize);
        ChannelBuffers[1].AddBuffer(rbuf, mergesize);
    }

    /// <summary>
    /// ストリーミングバッファをクリア
    /// </summary>
    public void ClearBuffer()
    {
        ChannelBuffers[0].ClearBuffer();
        ChannelBuffers[1].ClearBuffer();
    }

    public int GetBufferCount()
    {
        return ChannelBuffers[0].Buffercount;
    }

    /// <summary>
    /// 頻繁に呼んでバッファを補充する
    /// </summary>
    /// <returns></returns>
    public double Streaming()
    {
        double needsmsec = _streambuffermsec - bufwaveprovider16.BufferedDuration.TotalMilliseconds;

        if (needsmsec > 0)
        {
            Buffer2NAudio(_streambuffermsec);
        }
        return needsmsec;
    }

    /// <summary>
    /// 浮動小数点-1～1のリストをInt16(-32767～32767)に変換
    /// </summary>
    /// <param name="fList"></param>
    /// <returns></returns>
    private List<Int16> floatList2int16List(List<float> fList)
    {
        List<Int16> rtn = new List<Int16>();
        foreach (float f in fList)
        {
            if (f > 1)
                rtn.Add((Int16)(32767));
            else if (f < -1)
                rtn.Add((Int16)(-32767));
            else
                rtn.Add((Int16)(f * 32767));
        }
        return rtn;
    }
    /// <summary>
    /// Streaming()のバッファ管理を使用せず直接NAudioにデータを流す
    /// </summary>
    /// <param name="lbuf"></param>
    /// <param name="rbuf"></param>
    public void Direct2NAudioBuffer(List<float> lbuf, List<float> rbuf)
    {
        Direct2NAudioBuffer(floatList2int16List(lbuf), floatList2int16List(rbuf));
    }

    /// <summary>
    /// Streaming()のバッファ管理を使用せず直接NAudioにデータを流す
    /// </summary>
    /// <param name="lbuf"></param>
    /// <param name="rbuf"></param>
    public void Direct2NAudioBuffer(List<Int16> lbuf, List<Int16> rbuf)
    {

        List<Int16> mixbuf = new List<Int16>();
        for (int i = 0; i < lbuf.Count; i++)
        {
            mixbuf.Add(lbuf[i]);
            if (_Channels == 2)
            {
                mixbuf.Add(rbuf[i]);
            }
        }

        Int16[] intarray;
        intarray = mixbuf.ToArray();


        byte[] b;
        b = new byte[intarray.Length * 2 - 1 + 1];
        UInt16 tempUint;
        int cnt = 0;

        for (var i = 0; i <= intarray.Length - 1; i++)
        {
            if (intarray[i] >= 0)
                tempUint = (UInt16)intarray[i];
            else
                tempUint = (UInt16)(65536 + intarray[i]);
            b[cnt] = (byte)(tempUint % 256);
            cnt += 1;
            b[cnt] = (byte)(tempUint / 256);
            cnt += 1;
        }

        bufwaveprovider16.AddSamples(b, 0, b.Length);

    }

    /// <summary>
    /// NAUDIOのバッファにデータを流す
    /// </summary>
    /// <param name="intarray"></param>
    /// <remarks></remarks>
    private void Buffer2NAudio(double needsmsec)
    {
        int samplecount = (int)(_SamplingRate * needsmsec / 1000);
        List<Int16> lbuf = ChannelBuffers[0].GetBuffer(samplecount);
        List<Int16> rbuf = new List<short>();
        if (_Channels == 2)
        {
            rbuf = ChannelBuffers[1].GetBuffer(samplecount);
        }
        Direct2NAudioBuffer(lbuf, rbuf);

    }

    #region "ストリーミングバッファ管理用ローカルクラス
    /// <summary>
    /// 1チャンネル分のストリーミングRAWデータを管理するクラス
    /// ストリーミングに使うbufwaveproviderはFloat型が無理でバイト配列(16bit)のみ受け取れる
    /// </summary>
    private class Int16Buffer
    {
        private List<Int16> buffList;

        public Int16Buffer()
        {
            buffList = new List<Int16>();
        }
        #region"公開関数"

        /// <summary>
        /// このチャンネルにWAVE_RAWデータのリストを追加する
        /// </summary>
        /// <param name="lst"></param>
        /// <remarks></remarks>
        public void AddBuffer(List<Int16> lst, int mergesize)
        {
            List<Int16> templist = new List<Int16>();
            List<Int16> templist2 = new List<Int16>();
            List<Int16> templist3 = new List<Int16>();
            if (mergesize == 0)
            {
                buffList.AddRange(lst);
                return;
            }
            if (lst.Count == 0)
            {
                return;
            }
            if (buffList.Count == 0)
            {
                buffList.AddRange(lst);
                return;
            }

            if (buffList.Count > mergesize)
            {
                templist = buffList.GetRange(buffList.Count - mergesize, mergesize);
                buffList.RemoveRange(buffList.Count - mergesize, mergesize);
            }
            else
            {
                templist = buffList.GetRange(0, buffList.Count);
                buffList.RemoveRange(0, buffList.Count);
            }

            {
                templist2 = lst.GetRange(0, templist.Count);
                lst.RemoveRange(0, templist.Count);
                for (int i = 0; i < templist.Count; i++)
                {
                    templist3.Add(AddInt16(templist[i], templist2[i]));
                }
                buffList.AddRange(templist3);
                buffList.AddRange(lst);
            }

        }

        /// <summary>
        /// このチャンネルにWAVE_RAWデータのリストを追加する
        /// </summary>
        /// <param name="lst"></param>
        /// <remarks></remarks>
        public void ReplaceBuffer(List<Int16> lst)
        {
            buffList.Clear();
            buffList.AddRange(lst);
        }

        /// <summary>
        /// 残りバッファを捨てて初期化
        /// </summary>
        /// <remarks></remarks>
        public void ClearBuffer()
        {
            buffList.Clear();
        }

        /// <summary>
        /// 未再生のバッファ数
        /// </summary>
        /// <value></value>
        /// <returns></returns>
        /// <remarks></remarks>
        public int Buffercount
        {
            get
            {
                return buffList.Count;
            }
        }

        /// <summary>
        /// バッファを頭から指定サイズ取り出す（残り少なければ全部）
        /// </summary>
        /// <param name="GetBytes"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public List<Int16> GetBuffer(int GetBytes)
        {
            List<Int16> templist;
            if (buffList.Count > GetBytes)
            {
                templist = buffList.GetRange(0, GetBytes);
                buffList.RemoveRange(0, GetBytes);
            }
            else
            {
                templist = buffList.GetRange(0, buffList.Count);
                buffList.RemoveRange(0, buffList.Count);
            }
            return templist;
        }
        #endregion



    }
    #endregion

    #region"ローカル関数
    /// <summary>
    /// 足してInt16に収める。超えた値はMAXにしてしまう
    /// </summary>
    /// <param name="src"></param>
    /// <param name="dst"></param>
    /// <returns></returns>
    public static Int16 AddInt16(Int16 src, Int16 dst)
    {
        Int32 sum = src + dst;
        if (sum > 32767)
            return 32767;
        else if (sum < -32767)
            return -32767;
        else
            return (Int16)sum;
    }
    #endregion

}
